---
author: rodush
categories:
- composer
- PHP
- symfony
date: '2012-07-26T12:54:31+00:00'
tags:
- bundle alias
- doctrine-2.3
- entity
- form
- symfony-2.1
title: 'Form builder — entity field: «Class BundleAliasName:EntityClassName does not exist «'
type: post
url: /2012/07/form-builder-entity-field-class-bundlealiasnameentityclassname-does-not-exist/
vsw_pmvw_video_source:
- YouTube
wp-syntax-cache-content:
- 'a:2:{i:1;s:1104:"\n<div class="wp_syntax" style="position:relative;"><table><tr><td class="code"><pre class="php" style="font-family:monospace;"><span style="color: #000088;">$builder</span>\n            <span style="color: #339933;">-&gt;</span><span style="color: #004000;">add</span><span style="color: #009900;">&#40;</span>\n            <span style="color: #0000ff;">''field_name,\n            ''</span>entity<span style="color: #0000ff;">'',\n            array(\n                 ''</span><span style="color: #000000; font-weight: bold;">class</span><span style="color: #0000ff;">'' =&gt; ''</span>BundleAliasName<span style="color: #339933;">:</span>EntityClassName<span style="color: #0000ff;">'',\n                 ''</span>multiple<span style="color: #0000ff;">'' =&gt; true\n            )\n        )\n.....</span></pre></td></tr></table><p class="theCode" style="display:none;">$builder\n            -&gt;add(\n            ''field_name,\n            ''entity'',\n            array(\n                 ''class'' =&gt; ''BundleAliasName:EntityClassName'',\n                 ''multiple'' =&gt; true\n            )\n        )\n.....</p></div>\n";i:2;s:610:"\n<div class="wp_syntax" style="position:relative;"><table><tr><td class="code"><pre class="php" style="font-family:monospace;"><span style="color: #990000;">array</span><span style="color: #009900;">&#40;</span>\n    <span style="color: #0000ff;">''class''</span> <span style="color: #339933;">=&gt;</span> <span style="color: #0000ff;">''Full\Bundle\Path\Entity\EntityClassName''</span><span style="color: #339933;">,</span>\n<span style="color: #009900;">&#41;</span></pre></td></tr></table><p class="theCode" style="display:none;">array(\n    ''class'' =&gt; ''Full\Bundle\Path\Entity\EntityClassName'',\n)</p></div>\n";}\n'
---
После обновления symfony-2.1 до версии из транка (symfony-2.1.0-beta4) отвалилась форма, в которой я использовал поле типа entity, где в качестве класса сущности указал не полный путь к классу, а через bundle alias:

<pre lang="PHP">$builder
            ->add(
            'field_name,
            'entity',
            array(
                 'class' => 'BundleAliasName:EntityClassName',
                 'multiple' => true
            )
        )
.....
</pre>

Код выбрасывал исключение с сообщением 

> &#171;Class BundleAliasName:EntityClassName does not exist&#187;

Если прописать полный путь через пространство имен:

<pre lang="php">array(
    'class' => 'Full\Bundle\Path\Entity\EntityClassName',
)
</pre>

то все работало хорошо.
  
Я открыл по этому поводу [тикет][1] и оказалось, что дело в версии Doctrine! Обновление до 2.3 решило проблему!
  
Огромное спасибо автору комментария на гитхабе [Christophe Coevoet][2]!

 [1]: https://github.com/symfony/symfony/issues/5062
 [2]: https://github.com/stof