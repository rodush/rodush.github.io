---
author: rodush
categories:
- Без рубрики
date: '2011-08-02T07:03:15+00:00'
tags:
- continuous integration
- cruise control
title: как остановить CruiseControl
type: post
url: /2011/08/как-остановить-cruisecontrol/
---
Чтобы остановить сервер непрерывной интеграции CruiseControl, в веб-браузере перейдите по адресу:

> http://localhost:8000/invoke?operation=halt&objectname=CruiseControl+Manager%3Aid%3Dunique