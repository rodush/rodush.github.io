---
author: rodush
categories:
- symfony
- Web services
draft: true
tags:
- ckWebServicePlugin
- plugin
- symfony
- webservice
title: Пример использования csWebServicePlugin, symfony
type: post
---
В этой публикации я расскажу вам о замечательном плагине для symfony позволяющем в считанные минуты реализовать поддержку веб-сервисов на вашем сайте. Речь пойдет о ckWebServicePlugin, с помощью которого можно очень быстро превратить любой уже готовый метод контроллера в метод веб-сервиса.